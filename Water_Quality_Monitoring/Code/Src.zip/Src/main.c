/**
  ******************************************************************************
  * @file    Wifi/WiFi_HTTP_Server/src/main.c
  * @author  MCD Application Team
  * @brief   This file provides main program functions
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2017 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "wifi.h"
#include <stdio.h>
#include <string.h>
#include "stm32l4xx_hal_adc.h"
#include "stm32l4xx_hal_i2c.h"
#include "core_cm4.h"
#include <limits.h>

#ifdef __ICCARM__
#include <LowLevelIOInterface.h>
#endif

/* Private defines -----------------------------------------------------------*/
#define PORT           80

#define TERMINAL_USE


#define WIFI_WRITE_TIMEOUT 10000
#define WIFI_READ_TIMEOUT  10000
#define SOCKET                 0


#ifdef  TERMINAL_USE
#define LOG(a) printf a
#else
#define LOG(a)
#endif

#define SSID_SIZE     100
#define PASSWORD_SIZE 100
#define USER_CONF_MAGIC                 0x0123456789ABCDEFuLL


#define TS_HOST       "api.thingspeak.com"
#define TS_PORT       80
#define TS_WRITE_KEY  "WPV675IZJD54MQ1G"   /* Thingspeak write API*/

/* Hard-coded WiFi credentials */
#define MY_WIFI_SSID      "Apt 2423"
#define MY_WIFI_PASSWORD  "Med2423@wifi"
#define MY_WIFI_SECURITY  3   /* WPA2 */


/* ==  pH Helper method == */
#define PH_VREF    3.3f
#define PH_ADC_RES 4095.0f

/* These will need calibration with pH 4 & 7 solutions */
#define PH_SLOPE   -3.0f     // placeholder, adjust later
#define PH_OFFSET  21.0f     // placeholder, adjust later

#define ADS1115_ADDR       (0x48 << 1)   // ADDR->GND => 0x48, HAL wants 8-bit
#define ADS1115_REG_CONV   0x00
#define ADS1115_REG_CONFIG 0x01

/* ===== Quality thresholds (drinking-water style) ===== */
#define PH_GOOD_MIN     6.5f
#define PH_GOOD_MAX     8.5f
#define PH_OK_MIN       6.0f
#define PH_OK_MAX       9.0f

#define TDS_GOOD_MAX    300   // ppm
#define TDS_OK_MAX      600   // ppm

#define TURB_GOOD_MAX   5.0f   // NTU
#define TURB_OK_MAX     50.0f  // NTU




/* Private typedef------------------------------------------------------------*/

typedef struct {
  char ssid[SSID_SIZE];
  char password[PASSWORD_SIZE];
  uint8_t security;
} wifi_config_t;

typedef struct {
  uint64_t      wifi_config_magic;        /**< The USER_CONF_MAGIC magic word signals that the wifi config
                                               (wifi_config_t) is present in Flash. */
  wifi_config_t wifi_config;
} user_config_t;


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
#if defined (TERMINAL_USE)
extern UART_HandleTypeDef hDiscoUart;
#endif /* TERMINAL_USE */

//For pH sensor struct variable defining
ADC_HandleTypeDef hadc1;

//ADS115
I2C_HandleTypeDef hi2c1;

/* configuration storage in Flash memory */
#if defined(__ICCARM__)
/* IAR */
extern void __ICFEDIT_region_FIXED_LOC_start__;
const  user_config_t    *lUserConfigPtr = &__ICFEDIT_region_FIXED_LOC_start__;
#elif defined(__CC_ARM)
/* Keil / armcc */
user_config_t __uninited_region_start__ __attribute__((section("UNINIT_FIXED_LOC"), zero_init));
const  user_config_t    *lUserConfigPtr = &__uninited_region_start__;
#elif defined(__GNUC__)
/* GNU compiler */
user_config_t __uninited_region_start__ __attribute__((section("UNINIT_FIXED_LOC")));
const  user_config_t    *lUserConfigPtr = &__uninited_region_start__;
#endif

static volatile uint8_t button_flag = 0;
static user_config_t user_config;

static  uint8_t http[1024];
static  uint8_t  IP_Addr[4];
static  int     LedState = 0;

/* Private function prototypes -----------------------------------------------*/
#if defined (TERMINAL_USE)
#ifdef __GNUC__
/* With GCC, small printf (option LD Linker->Libraries->Small printf
   set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#define GETCHAR_PROTOTYPE int __io_getchar(void)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#define GETCHAR_PROTOTYPE int fgetc(FILE *f)
#endif /* __GNUC__ */
#endif /* TERMINAL_USE */

//static void SystemClock_Config(void);
//static WIFI_Status_t SendWebPage(uint8_t ledIsOn, uint8_t temperature);
//static int wifi_server(void);
//static int wifi_start(void);
//static int wifi_connect(void);
//static bool WebServerProcess(void);
//static void Button_ISR(void);
//static void Button_Reset(void);
//static uint8_t Button_WaitForPush(uint32_t delay);

/* === WiFi Module === */
static void SystemClock_Config(void);
static int  wifi_start(void);
static int  wifi_connect(void);
static void ThingSpeak_Send(float ph, float tempC, float tds, float turb_ntu);
static int  wifi_thingspeak_client(void);
static void Button_ISR(void);
static void Button_Reset(void);
static uint8_t Button_WaitForPush(uint32_t delay);

/* === pH sensor & TDS sensor === */
static void MX_ADC1_Init(void);
//static float PH_ReadVoltage_mV(void);
static float ADC_ReadA0_mV(void);
static float PH_ReadPH(void);
/* ====== TDS ======= */
static int TDS_ReadPPM(void);

/*===== Turbidity sensor ====*/
// --- Turbidity (DFRobot) using ADS1115 A2 + 4.7k/4.7k divider ---
static float TURB_ReadVoltage_V(void);
static float TURB_VoltageToNTU(float v_sensor_V);
static float TURB_ReadNTU(void);

/* ===== DS18B20 on PB2 - Temperature sensor ===== */
#define ONEWIRE_PORT      GPIOB
#define ONEWIRE_PIN       GPIO_PIN_2

static void DWT_Delay_Init(void);
static void delay_us(uint32_t us);

static void DS18B20_GPIO_Init(void);
static uint8_t OneWire_Reset(void);
static void OneWire_WriteBit(uint8_t bit);
static uint8_t OneWire_ReadBit(void);
static void OneWire_WriteByte(uint8_t byte);
static uint8_t OneWire_ReadByte(void);
static float DS18B20_ReadTempC(void);


//==== ADS1115====
static void MX_I2C1_Init(void);
static int16_t ADS1115_ReadSingleEnded(uint8_t channel);
static float ADS1115_RawToVoltage(int16_t raw);
static float ADS1115_Read_mV(uint8_t channel);

/* Private functions ---------------------------------------------------------*/
/**
  * @brief  Main program
  * @param  None
  * @retval None
  *
  *
  */


//==============ADS1115==================
void HAL_I2C_MspInit(I2C_HandleTypeDef* hi2c)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  if (hi2c->Instance == I2C1)
  {
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_I2C1_CLK_ENABLE();

    // PB8 = I2C1_SCL (Arduino D15), PB9 = I2C1_SDA (Arduino D14)
    GPIO_InitStruct.Pin = GPIO_PIN_8 | GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  }
}

static void MX_I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00707CBB;          // 100kHz typical for STM32L4 @ 80MHz
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;

  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    printf("[I2C] HAL_I2C_Init FAILED\r\n");
    Error_Handler();
  }

  HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE);
}





void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  if (hadc->Instance == ADC1)
  {
    __HAL_RCC_ADC_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    /* PC5 -> A0 (ADC1_IN14) */
    GPIO_InitStruct.Pin  = GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    printf("[ADC MSP] PC5 configured as analog\r\n");
  }
}




void Error_Handler(void)
{
  /* Simple trap: stay here if something goes wrong */
  while (1)
  {
  }
}


int main(void)
{
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();


  /* WIFI Web Server demonstration */
#if defined (TERMINAL_USE)
  /* Initialize all configured peripherals */
  hDiscoUart.Instance = DISCOVERY_COM1;
  hDiscoUart.Init.BaudRate = 115200;
  hDiscoUart.Init.WordLength = UART_WORDLENGTH_8B;
  hDiscoUart.Init.StopBits = UART_STOPBITS_1;
  hDiscoUart.Init.Parity = UART_PARITY_NONE;
  hDiscoUart.Init.Mode = UART_MODE_TX_RX;
  hDiscoUart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  hDiscoUart.Init.OverSampling = UART_OVERSAMPLING_16;
  hDiscoUart.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  hDiscoUart.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;




  BSP_COM_Init(COM1, &hDiscoUart);
  BSP_TSENSOR_Init();

  printf("\n****** WIFI Web Server demonstration ******\n\n");

#endif /* TERMINAL_USE */

  /* ADD THIS: initialize ADC for pH sensor */
   //MX_ADC1_Init();
   MX_I2C1_Init();


   if (HAL_I2C_IsDeviceReady(&hi2c1, ADS1115_ADDR, 3, 200) == HAL_OK)
     printf("[ADS] ADS1115 detected at 0x48\r\n");
   else
     printf("[ADS] ADS1115 NOT detected at 0x48\r\n");

   /* Enable microsecond delay using DWT for 1-Wire timing */
   DWT_Delay_Init();

   /* Init GPIO for DS18B20: PB2 (Arduino D8) as open-drain with pull-up */
   DS18B20_GPIO_Init();

   /* Configure LED2 */
   BSP_LED_Init(LED2);

   /* USER push button is used to ask if reconfiguration is needed */
   BSP_PB_Init(BUTTON_USER, BUTTON_MODE_EXTI);

  //wifi_server();
  wifi_thingspeak_client();
}

/**
  * @brief  Send HTML page
  * @param  None
  * @retval None
  */

static const char* PH_Label(float ph)
{
  if (ph >= PH_GOOD_MIN && ph <= PH_GOOD_MAX) return "Good";
  if (ph >= PH_OK_MIN   && ph <= PH_OK_MAX)   return "Medium";
  return "Bad";
}

static const char* TDS_Label(int tds_ppm)
{
  if (tds_ppm <= TDS_GOOD_MAX) return "Good";
  if (tds_ppm <= TDS_OK_MAX)   return "Medium";
  return "Bad";
}

static const char* TURB_Label(float ntu)
{
  if (ntu <= TURB_GOOD_MAX) return "Good";
  if (ntu <= TURB_OK_MAX)   return "Medium";
  return "Bad";
}



static int wifi_start(void)
{
  uint8_t  MAC_Addr[6];

 /*Initialize and use WIFI module */
  if(WIFI_Init() ==  WIFI_STATUS_OK)
  {
    printf("eS-WiFi Initialized.\n");
    if(WIFI_GetMAC_Address(MAC_Addr, sizeof(MAC_Addr)) == WIFI_STATUS_OK)
    {
      LOG(("eS-WiFi module MAC Address : %02X:%02X:%02X:%02X:%02X:%02X\n",
               MAC_Addr[0],
               MAC_Addr[1],
               MAC_Addr[2],
               MAC_Addr[3],
               MAC_Addr[4],
               MAC_Addr[5]));
    }
    else
    {
      LOG(("> ERROR : CANNOT get MAC address\n"));
      return -1;
    }
  }
  else
  {
    return -1;
  }
  return 0;
}


int wifi_connect(void)
{
  /* Initialize WiFi module */
  if (wifi_start() != 0)
  {
    LOG(("ERROR: wifi_start() failed\n"));
    return -1;
  }

  /* Fill user_config from hard-coded defines (Flash is no longer used) */
  memset(&user_config, 0, sizeof(user_config));
  strncpy(user_config.wifi_config.ssid, MY_WIFI_SSID, SSID_SIZE - 1);
  strncpy(user_config.wifi_config.password, MY_WIFI_PASSWORD, PASSWORD_SIZE - 1);
  user_config.wifi_config.security = MY_WIFI_SECURITY;

  printf("\nConnecting to %s\n", user_config.wifi_config.ssid);

  /* Map numeric security (0–3) to WIFI_Ecn_t enum */
  WIFI_Ecn_t security;
  switch (user_config.wifi_config.security)
  {
    case 0:
      security = WIFI_ECN_OPEN;
      break;
    case 1:
      security = WIFI_ECN_WEP;
      break;
    case 2:
      security = WIFI_ECN_WPA_PSK;
      break;
    case 3:
    default:
      security = WIFI_ECN_WPA2_PSK;
      break;
  }

  /* Connect using hard-coded credentials */
  if (WIFI_Connect(user_config.wifi_config.ssid,
                   user_config.wifi_config.password,
                   security) == WIFI_STATUS_OK)
  {
    if (WIFI_GetIP_Address(IP_Addr, sizeof(IP_Addr)) == WIFI_STATUS_OK)
    {
      LOG(("eS-WiFi module connected: got IP Address : %d.%d.%d.%d\n",
           IP_Addr[0],
           IP_Addr[1],
           IP_Addr[2],
           IP_Addr[3]));
      return 0;
    }
    else
    {
      LOG((" ERROR : es-wifi module CANNOT get IP address\n"));
      return -1;
    }
  }
  else
  {
    LOG(("ERROR : es-wifi module NOT connected\n"));
    return -1;
  }
}


/* ======================= ThingSpeak client code ======================= */

/**
  * @brief  Send one value to ThingSpeak (field1)
  */
static void ThingSpeak_Send(float ph, float tempC, float tds, float turb_ntu)
{
  WIFI_Status_t wifi_ret;
  uint8_t ipaddr[4];

  int temp_int = (int)(tempC * 100.0f + 0.5f);  // °C * 100
  int ph_int   = (int)(ph   * 100.0f + 0.5f);  // pH * 100
  int tds_int  = (int)(tds  + 0.5f);           // TDS in ppm, integer
  int turb_x10 = (int)(turb_ntu * 10.0f + 0.5f);
  /* 1) DNS: resolve api.thingspeak.com */
  wifi_ret = WIFI_GetHostAddress(TS_HOST, ipaddr, sizeof(ipaddr));
  if (wifi_ret != WIFI_STATUS_OK)
  {
    printf("DNS failed for %s (err=%d)\r\n", TS_HOST, wifi_ret);
    return;
  }

  printf("ThingSpeak IP: %d.%d.%d.%d\r\n",
         ipaddr[0], ipaddr[1], ipaddr[2], ipaddr[3]);

  /* 2) Open TCP client connection on socket 0 */
  wifi_ret = WIFI_OpenClientConnection(0,
                                       WIFI_TCP_PROTOCOL,
                                       "TS",
                                       ipaddr,
                                       TS_PORT,
                                       0);
  if (wifi_ret != WIFI_STATUS_OK)
  {
    printf("WIFI_OpenClientConnection failed (err=%d)\r\n", wifi_ret);
    return;
  }

  /* 3) Build HTTP GET request:
         field1 = pH, field2 = temperature (°C), field3 = TDS (ppm) */
  char http_buf[256];

  int len = snprintf(http_buf, sizeof(http_buf),
                     "GET /update?api_key=%s"
                     "&field1=%d.%02d"
                     "&field2=%d.%02d"
		  	  	  	 "&field3=%d.%02d"
		  	  	  	 "&field4=%d.%01d HTTP/1.1\r\n"
                     "Host: " TS_HOST "\r\n"
                     "Connection: close\r\n\r\n",
                     TS_WRITE_KEY,
                     ph_int   / 100, ph_int   % 100,
                     temp_int / 100, temp_int % 100,
                     tds_int,
					 turb_x10 / 10, turb_x10 % 10);

  if (len <= 0 || len >= (int)sizeof(http_buf))
  {
    printf("HTTP buffer too small\r\n");
    WIFI_CloseClientConnection(0);
    return;
  }

  /* 4) Send request */
  uint16_t sent_len = 0;
  wifi_ret = WIFI_SendData(0,
                           (uint8_t *)http_buf,
                           (uint16_t)len,
                           &sent_len,
                           WIFI_WRITE_TIMEOUT);

  if (wifi_ret != WIFI_STATUS_OK)
  {
    printf("WIFI_SendData failed (err=%d)\r\n", wifi_ret);
    WIFI_CloseClientConnection(0);
    return;
  }

  printf("Sent %u bytes to ThingSpeak\r\n", sent_len);

  /* 5) Read & ignore HTTP response */
  uint8_t rx_buf[64];
  uint16_t rcv_len = 0;
  WIFI_ReceiveData(0, rx_buf, sizeof(rx_buf), &rcv_len, WIFI_READ_TIMEOUT);

  /* 6) Close connection */
  WIFI_CloseClientConnection(0);

  printf("ThingSpeak update done (pH=%d.%02d, temp=%d.%02d, TDS=%d ppm, TUB=%d.%01d NTU)\r\n",
         ph_int   / 100, ph_int   % 100,
         temp_int / 100, temp_int % 100,
         tds_int,
		 turb_x10 / 10, turb_x10 % 10);
}



static int wifi_thingspeak_client(void)
{
  LOG(("\nRunning ThingSpeak client\n"));

  if (wifi_connect() != 0)
  {
    LOG(("WiFi connect failed\n"));
    return -1;
  }

  LOG(("WiFi connected, starting ThingSpeak loop...\n"));

  while (1)
  {
      /* Read pH from sensor on A0 (PC5) */
      float ph = PH_ReadPH();
      //printf("%f",ph);

      int ph_x100 = (int)(ph * 100.0f + 0.5f);
//      printf("Measured pH: %d.%02d\r\n",
//             ph_x100 / 100,
//             ph_x100 % 100);

      /* Read TDS from same A0 (TDS meter connected instead of / or in place of pH board) */
      int tds_ppm = TDS_ReadPPM();
//      printf("Measured TDS: %d ppm\r\n", tds_ppm);

      /* Read temperature from DS18B20 on PB2 (D8) */
      float tempC = DS18B20_ReadTempC();
      int32_t temp_x100 = (int32_t)(tempC * 100.0f + 0.5f);

      /* Turbidity sensor */

      float turb_ntu = TURB_ReadNTU();
      int32_t turb_x10 = (int32_t)(turb_ntu * 10.0f + 0.5f);

//      printf("[TURB] Turbidity Value = %ld.%01ld NTU\r\n",
//             (long)(turb_x10 / 10),
//             (long)(turb_x10 % 10));

      printf("----- Water Quality Summary -----\r\n");
      printf("pH : %d.%02d - %s\r\n",
    		  ph_x100/100, ph_x100%100, PH_Label(ph));

      printf("TDS: %d ppm - %s\r\n",
             tds_ppm, TDS_Label(tds_ppm));

      printf("TUB: %d.%01d NTU - %s\r\n",
             turb_x10/10, turb_x10%10, TURB_Label(turb_ntu));

      printf("TEMP: %ld.%02ld°C\r\n",
             (long)(temp_x100 / 100),
             (long)(temp_x100 % 100));

      printf("---------------------------------\r\n");

      /* Send pH, temperature, and TDS to ThingSpeak */
      ThingSpeak_Send(ph, tempC, (float)tds_ppm, turb_ntu);

      /* ThingSpeak allows ~1 update / 15 s; use 20 s for safety */
      HAL_Delay(30000);
  }

  /* not reached */
  /* return 0; */
}



static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef       RCC_ClkInitStruct;
  RCC_OscInitTypeDef       RCC_OscInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /* MSI is enabled after System reset, activate PLL with MSI as source */
  RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState            = RCC_MSI_ON;
  RCC_OscInitStruct.MSIClockRange       = RCC_MSIRANGE_6;
  RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM            = 1;
  RCC_OscInitStruct.PLL.PLLN            = 40;
  RCC_OscInitStruct.PLL.PLLR            = 2;
  RCC_OscInitStruct.PLL.PLLP            = 7;
  RCC_OscInitStruct.PLL.PLLQ            = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    /* Initialization Error */
    while (1);
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 clocks dividers */
  RCC_ClkInitStruct.ClockType      = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK |
                                      RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    /* Initialization Error */
    while (1);
  }

  /* === NEW: select kernel clock for ADC1 === */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection    = RCC_ADCCLKSOURCE_SYSCLK;  // you can change to PLLSAI1 if needed
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    /* Initialization Error */
    while (1);
  }
}




/**
  * @brief Reset button state
  *        To be called before Button_WaitForPush()
  */
void Button_Reset()
{
  button_flag = 0;
}

/**
  * @brief Waiting for button to be pushed
  */
uint8_t Button_WaitForPush(uint32_t delay)
{
  uint32_t time_out = HAL_GetTick() + delay;

  do
  {
    if (button_flag > 0)
    {
      return button_flag;
    }
    HAL_Delay(100);
  }
  while (HAL_GetTick() < time_out);

  return 0;
}



static int16_t ADS1115_ReadSingleEnded(uint8_t channel)
{
  uint16_t config = 0;

  config |= (1 << 15);                 // start conversion
  config |= ((0x04 + channel) << 12);  // AINx vs GND
  config |= (1 << 9);                  // single-shot
  config |= (1 << 8);                  // PGA ±4.096V
  config |= (4 << 5);                  // 128 SPS
  config |= (3 << 0);                  // comparator disabled

  uint8_t tx[3] = { ADS1115_REG_CONFIG, (uint8_t)(config >> 8), (uint8_t)(config & 0xFF) };

  HAL_StatusTypeDef st;
  st = HAL_I2C_Master_Transmit(&hi2c1, ADS1115_ADDR, tx, 3, 200);
  if (st != HAL_OK) {
    printf("[ADS] TX cfg failed st=%d err=0x%08lX\r\n", st, (unsigned long)HAL_I2C_GetError(&hi2c1));
    return INT16_MIN;
  }

  HAL_Delay(10);

  uint8_t reg = ADS1115_REG_CONV;
  st = HAL_I2C_Master_Transmit(&hi2c1, ADS1115_ADDR, &reg, 1, 200);
  if (st != HAL_OK) {
    printf("[ADS] TX reg failed st=%d err=0x%08lX\r\n", st, (unsigned long)HAL_I2C_GetError(&hi2c1));
    return INT16_MIN;
  }

  uint8_t rx[2];
  st = HAL_I2C_Master_Receive(&hi2c1, ADS1115_ADDR, rx, 2, 200);
  if (st != HAL_OK) {
    printf("[ADS] RX conv failed st=%d err=0x%08lX\r\n", st, (unsigned long)HAL_I2C_GetError(&hi2c1));
    return INT16_MIN;
  }

  return (int16_t)((rx[0] << 8) | rx[1]);
}


static float ADS1115_RawToVoltage(int16_t raw)
{
  // PGA=±4.096V => 4.096/32768 V per count
  return ((float)raw * 4.096f) / 32768.0f;
}

static float ADS1115_Read_mV(uint8_t channel)
{
  const int samples = 8;
  int32_t acc = 0;
  int ok = 0;

  for (int i = 0; i < samples; i++)
  {
    int16_t r = ADS1115_ReadSingleEnded(channel);

    if (r == INT16_MIN)
    {
      // I2C failed for this sample; skip it
      printf("[ADS] ch=%d sample %d: I2C error (no data)\r\n", channel, i);
      continue;
    }

    acc += r;
    ok++;
  }

  if (ok == 0)
  {
    printf("[ADS] ch=%d: ALL samples failed -> check SDA/SCL/ADDR/power\r\n", channel);
    return 0.0f;
  }

  int16_t avg = (int16_t)(acc / ok);
  float v  = ADS1115_RawToVoltage(avg);
  float mv = v * 1000.0f;

  printf("[ADS] ch=%d raw=%d mv=%ld (ok=%d/%d)\r\n",
         channel, (int)avg, (long)mv, ok, samples);

  return mv;
}



static float PH_ReadPH(void)
{

   float v_mV = ADS1115_Read_mV(0);  // A0

  // Basic sanity check
  if (v_mV < 1.0f) {
	  int v10 = (int)(v_mV * 10.0f + 0.5f);  // e.g. 3293.4 -> 32934

	     printf("pH: ADC too low (%d.%01d mV), returning 0\r\n",
	            v10 / 10,      // integer part
	            v10 % 10);     // 1 decimal digit

	     return 0.0f;
  }

  float fullscale_mV = PH_VREF * 1000.0f;

  // Simple linear map: 0..Vref  ->  0..14
  float ph = 14.0f * (v_mV / fullscale_mV);

  if (ph < 0.0f)  ph = 0.0f;
  if (ph > 14.0f) ph = 14.0f;

  int ph_x100  = (int)(ph * 100.0f + 0.5f);   // pH * 100

//  printf("Computed pH = %d.%02d from %ld mV\r\n",
//         ph_x100 / 100,        // integer part of pH
//         ph_x100 % 100,        // two decimal places
//         (long)v_mV);

  return ph;
}





/* === TDS Meter helper (using same ADC on A0) === */
#define TDS_CALIB_K  0.08f   // <-- we will tune this
//#define TDS_CALIB_K  (100.0f / 800.0f)   // 0.125f


static int TDS_ReadPPM(void)
{
  float v_mV = ADS1115_Read_mV(1);   // A1

  if (v_mV < 50.0f)
  {
    return 0;
  }

  float v = v_mV / 1000.0f;   // volts

  /* Raw DFRobot TDS formula */
  float raw_tds = (133.42f * v * v * v
                 - 255.86f * v * v
                 + 857.39f * v) * 0.5f;

  if (raw_tds < 0.0f)
    raw_tds = 0.0f;

  /* Apply calibration factor */
  float tds = raw_tds * TDS_CALIB_K;

  int tds_int = (int)(tds + 0.5f);

//  printf("TDS raw = %ld ppm, calibrated = %d ppm from %ld mV\r\n",
//         (long)raw_tds,
//         tds_int,
//         (long)v_mV);

  return tds_int;
}

/*======== Turbidity sensor =====*/
static float TURB_ReadVoltage_V(void)
{
    // ADS A2 reads the divided voltage (Vin/2)
    float v_adc_mV = ADS1115_Read_mV(2);

    // Convert back to sensor output voltage (because divider = 0.5)
    float v_sensor_mV = v_adc_mV * 2.0f;
    return v_sensor_mV / 1000.0f;   // return volts
}

static float TURB_VoltageToNTU(float v_sensor_V)
{
    float ntu;

    if (v_sensor_V < 2.5f)
        ntu = 3000.0f;
    else
        ntu = -1120.4f*v_sensor_V*v_sensor_V + 5742.3f*v_sensor_V - 4352.9f;

    if (ntu < 0) ntu = 0;
    return ntu;
}


static float TURB_ReadNTU(void)
{
    float v = TURB_ReadVoltage_V();          // volts
    float ntu = TURB_VoltageToNTU(v);

    int32_t v_mV = (int32_t)(v * 1000.0f + 0.5f);
    int32_t ntu_x10 = (int32_t)(ntu * 10.0f + 0.5f);

    printf("[TURB] V=%ld mV, NTU=%ld.%01ld\r\n",
           (long)v_mV,
           (long)(ntu_x10/10), (long)(ntu_x10%10));

    return ntu;
}






/* ===== Temperature sensor ===== */
static void DWT_Delay_Init(void)
{
  /* Enable trace and debug block DEMCR (TRCENA) */
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;

  /* Reset cycle counter */
  DWT->CYCCNT = 0;

  /* Enable cycle counter */
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

static void delay_us(uint32_t us)
{
  uint32_t cycles = (SystemCoreClock / 1000000U) * us;
  uint32_t start  = DWT->CYCCNT;

  while ((DWT->CYCCNT - start) < cycles)
  {
    __NOP();
  }
}


/* ===== DS18B20 / 1-Wire implementation ===== */

static void DS18B20_GPIO_Init(void)
{
  __HAL_RCC_GPIOB_CLK_ENABLE();

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Pin   = ONEWIRE_PIN;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_OD;  // open-drain
  GPIO_InitStruct.Pull  = GPIO_PULLUP;          // on-chip pull-up; still use external 4.7k
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(ONEWIRE_PORT, &GPIO_InitStruct);

  HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_SET); // line idle high
}

/* 1-Wire reset: returns 1 if a device is present, 0 otherwise */
static uint8_t OneWire_Reset(void)
{
  uint8_t presence = 0;

  /* Pull bus low for reset pulse (~480 µs) */
  HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_RESET);
  delay_us(480);

  /* Release bus and wait 70 µs, then sample */
  HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_SET);
  delay_us(70);

  presence = (HAL_GPIO_ReadPin(ONEWIRE_PORT, ONEWIRE_PIN) == GPIO_PIN_RESET) ? 1U : 0U;

  /* Wait for remainder of timeslot (~410 µs) */
  delay_us(410);

  return presence;
}

static void OneWire_WriteBit(uint8_t bit)
{
  if (bit)
  {
    /* Write '1' slot */
    HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_RESET);
    delay_us(6);
    HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_SET);
    delay_us(64);
  }
  else
  {
    /* Write '0' slot */
    HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_RESET);
    delay_us(60);
    HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_SET);
    delay_us(10);
  }
}

static uint8_t OneWire_ReadBit(void)
{
  uint8_t bit;

  /* Initiate read slot */
  HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_RESET);
  delay_us(6);
  HAL_GPIO_WritePin(ONEWIRE_PORT, ONEWIRE_PIN, GPIO_PIN_SET);
  delay_us(9);

  bit = (HAL_GPIO_ReadPin(ONEWIRE_PORT, ONEWIRE_PIN) == GPIO_PIN_SET) ? 1U : 0U;

  /* Wait for end of timeslot */
  delay_us(55);

  return bit;
}

static void OneWire_WriteByte(uint8_t byte)
{
  for (int i = 0; i < 8; i++)
  {
    OneWire_WriteBit(byte & 0x01U);
    byte >>= 1;
  }
}

static uint8_t OneWire_ReadByte(void)
{
  uint8_t byte = 0;

  for (int i = 0; i < 8; i++)
  {
    byte >>= 1;
    if (OneWire_ReadBit())
    {
      byte |= 0x80U;
    }
  }
  return byte;
}

/* Read temperature in °C from a single DS18B20 on the bus */
static float DS18B20_ReadTempC(void)
{
  uint8_t scratch[9];

  if (!OneWire_Reset())
  {
    printf("DS18B20 not detected on 1-Wire bus\r\n");
    return -1000.0f;   // error sentinel
  }

  /* Skip ROM (single device) and start temperature conversion */
  OneWire_WriteByte(0xCC);  // SKIP ROM
  OneWire_WriteByte(0x44);  // CONVERT T

  /* Wait for conversion (max 750 ms for 12-bit) */
  HAL_Delay(750);

  if (!OneWire_Reset())
  {
    printf("DS18B20 not responding after CONVERT T\r\n");
    return -1000.0f;
  }

  /* Skip ROM and read scratchpad */
  OneWire_WriteByte(0xCC);  // SKIP ROM
  OneWire_WriteByte(0xBE);  // READ SCRATCHPAD

  for (int i = 0; i < 9; i++)
  {
    scratch[i] = OneWire_ReadByte();
  }

  /* Temperature is in first two bytes (LSB, MSB) */
  int16_t rawTemp = (int16_t)((scratch[1] << 8) | scratch[0]);

  /* DS18B20 resolution: 1 LSB = 0.0625 °C (2^-4) */
  float tempC = (float)rawTemp / 16.0f;

  return tempC;
}







#if defined (TERMINAL_USE)
/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART1 and Loop until the end of transmission */
  HAL_UART_Transmit(&hDiscoUart, (uint8_t *)&ch, 1, 0xFFFF);

  return ch;
}



#ifdef __ICCARM__
/**
  * @brief
  * @param
  * @retval
  */
size_t __read(int handle, unsigned char * buffer, size_t size)
{
  int nChars = 0;

  /* handle ? */

  for (/* Empty */; size > 0; --size)
  {
    uint8_t ch = 0;
    while (HAL_OK != HAL_UART_Receive(&hDiscoUart, (uint8_t *)&ch, 1, 30000))
    {
      ;
    }

    *buffer++ = ch;
    ++nChars;
  }

  return nChars;
}
#elif defined(__CC_ARM) || defined(__GNUC__)
/**
  * @brief  Retargets the C library scanf function to the USART.
  * @param  None
  * @retval None
  */
GETCHAR_PROTOTYPE
{
  /* Place your implementation of fgetc here */
  /* e.g. read a character on USART and loop until the end of read */
  uint8_t ch = 0;
  while (HAL_OK != HAL_UART_Receive(&hDiscoUart, (uint8_t *)&ch, 1, 30000))
  {
    ;
  }
  return ch;
}
#endif /* defined(__CC_ARM)  */
#endif /* TERMINAL_USE */

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif


/**
  * @brief  EXTI line detection callback.
  * @param  GPIO_Pin: Specifies the port pin connected to corresponding EXTI line.
  * @retval None
  */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  switch (GPIO_Pin)
  {
    case (USER_BUTTON_PIN):
    {
      Button_ISR();
      break;
    }
    case (GPIO_PIN_1):
    {
      SPI_WIFI_ISR();
      break;
    }
    default:
    {
      break;
    }
  }
}

/**
  * @brief  SPI3 line detection callback.
  * @param  None
  * @retval None
  */
void SPI3_IRQHandler(void)
{
  HAL_SPI_IRQHandler(&hspi);
}

/**
  * @brief Update button ISR status
  */
static void Button_ISR(void)
{
  button_flag++;
}


